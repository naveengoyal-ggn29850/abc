/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaPack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;


/**
 *
 * @author Nknitish
 */
public class JavaClass {
    
    
    //******Jdbc
    
    public static String driver="com.microsoft.sqlserver.jdbc.SQLServerDriver";
    public static String url="jdbc:sqlserver://localhost:1433;databaseName=Niit_Repurches_System";
    public static String user="naveen";
    public static String upassword="12345";
    
    
    // Faculity
    public static ArrayList<String> faculity()
    {
     
         ArrayList<String> fact= new ArrayList<String>();
          try{
          Class.forName(driver);
           Connection con=DriverManager.getConnection(url,user,upassword);
           
           String qury="select fname , fempcode from F_Login";
           
           Statement st=con.createStatement();
           ResultSet rs=st.executeQuery(qury);
           
           while(rs.next())
           {
               String a=rs.getString("fname"); 
               String b=rs.getString("fempcode");
               String c=a+"-"+b;
               fact.add(c);
            
           }
           
           }catch(Exception ex)
           {}
        
          return fact;
    
    }
    
    //****************************************
    // Course
    
    
    
    public static ArrayList<String> getCourse()
    {
      
         
         ArrayList<String> course= new ArrayList<String>();
          try{
          Class.forName(driver);
           Connection con=DriverManager.getConnection(url,user,upassword);
           
           String qury="select  course_Name from Niit_Course";
           
           Statement st=con.createStatement();
           ResultSet rs=st.executeQuery(qury);
           
           while(rs.next())
           {
               String a=rs.getString("course_Name"); 
               course.add(a);
              
           }
           
           }catch(Exception ex)
           {}
        
          return course;
    
    }
    
    
    
     // Course
    
    //*********************************Course With /Studnt ID
    
    public static ArrayList<String> getCourse(String x)
    {
        ArrayList<String> tscourse= new ArrayList<String>();
      
          try{
          Class.forName(driver);
           Connection con=DriverManager.getConnection(url,user,upassword);
           
           String qury="select scname from Student_course where ssid='"+x+"' ";
           
           Statement st=con.createStatement();
           ResultSet rs=st.executeQuery(qury);
          
           while(rs.next())
           {
               String a=rs.getString("scname"); 
              
               tscourse.add(a);
           
           }
           
           }catch(Exception ex)
           {}
        
          return tscourse;
    
    }
    
    //****************************************

    public static String rep_Sid_String(String s)
    {
         ArrayList<String> a = rep_Sid(s);
         String temp="";
         for(String k :a)
         {
         temp+=k+" | ";
         }
         return temp;
    }
    
   //******************************** 
    public static String getCourse_String(String s)
    {
         ArrayList<String> a = getCourse(s);
         String temp="";
         for(String k :a)
         {
         temp+=k+" | ";
         }
         return temp;
    }
    
    
    //****************************************
    public static ArrayList<String> rep_Sid(String s)
    {
       
    ArrayList<String> a = getCourse(s);
    ArrayList <String> a1= new ArrayList<>();
    
    a.stream().forEach((String k) -> {
        a1.add(throwcourse(k));
    });
    
    ArrayList <String> a2= new ArrayList<>();
     
     
    a1.stream().map((k) -> k.split("/")).forEach((temp1) -> {
         a2.addAll(Arrays.asList(temp1));
    });
     
    Set<String> set= new HashSet<>(a2);
    a2.clear();
    a2.addAll(set);
     
    // Remove Student Course from Re Purches Course
    
    
    a2.removeAll(a);
    
    // Remove Student Course According To Their Education
    ArrayList <String> a3=check_Edu(s,a2);
    a2.removeAll(a3);
     

    return a2;
   
    }
    
     //****************************************

    
    public static String throwcourse(String course)
    {
        String rcs="";
        switch(course)
        {
            
            case "C" :
                rcs="C++/CORE JAVA/ADV JAVA";//"C++/CORE JAVA/ADV JAVA/PGPJAVA/PYTHON";
             break;
            case "C++" :
                rcs="CORE JAVA/ADV JAVA/PGPJAVA/PYTHON/RDBMS";
             break;
            case "BASIC" :
                rcs="ADV EXCEL/C/C++/ANIIT/GNIIT"; //"C/C++/ADV EXCEL/PGPJAVA/PYTHON/ANIIT/GNIIT";
             break;
            case "GNIIT" :
                rcs="PYTHON/R";
             break;
            case "CORE JAVA" :
                rcs="ADV JAVA/PGPJAVA/PYTHON"; //"ADV JAVA/PGPJAVA/PYTHON/RDBMS/R";
             break;
             case "PYTHON" :
                rcs="ADV JAVA/PGPJAVA/RDBMS/R";
             break;  
             case "PGPJAVA" :
                 rcs="PYTHON/R";
                 break;
             default:
                 rcs="";//"ANYTHING";
                 break;
     
        }
        
        return rcs;
        
    }

    public static ArrayList<String> check_Edu(String s, ArrayList<String> a2) {
       
        ArrayList<String> tedu= new ArrayList<String>();
        String pg="NA",g="NA",tw="NA",tn="NA",bt="NA";
          try{
          Class.forName(driver);
           Connection con=DriverManager.getConnection(url,user,upassword);
           
           String qury1="select sstatus from Student_Edu where ssid='"+s+"' and edu='POST_GRADUATION'";
           String qury2="select sstatus from Student_Edu where ssid='"+s+"' and edu='GRADUATION'";
           String qury3="select sstatus from Student_Edu where ssid='"+s+"' and edu='12TH'";
           String qury4="select sstatus from Student_Edu where ssid='"+s+"' and edu='10TH'";
           String qury5="select sstatus from Student_Edu where ssid='"+s+"' and edu='BELOW10TH'";
           
           Statement st1=con.createStatement();
           Statement st2=con.createStatement();
           Statement st3=con.createStatement();
           Statement st4=con.createStatement();
           Statement st5=con.createStatement();
          
           ResultSet rs1=st1.executeQuery(qury1);
           ResultSet rs2=st2.executeQuery(qury2);
           ResultSet rs3=st3.executeQuery(qury3);
           ResultSet rs4=st4.executeQuery(qury4);
           ResultSet rs5=st5.executeQuery(qury5);
        
           if(rs1.next())
           {          
               pg=rs1.getString("sstatus");
               
           }
           if(rs2.next())
           {          
               g=rs2.getString("sstatus");
               
           }
           if(rs3.next())
           {          
               tw=rs3.getString("sstatus");
               
           }
           if(rs4.next())
           {          
               tn=rs4.getString("sstatus");
               
           }
           if(rs5.next())
           {          
               bt=rs5.getString("sstatus");
               
           }
           
           }catch(Exception ex)
           {    
               a2.add("Exception"+ex.getMessage());
               System.out.println("Exception:" +ex.getMessage());
           }

         
           for(String k:a2)
           {
              if(k.equals("GNIIT"))
              {
                  if(g.equals("PURSUING") || tw.equals("PASS")){
                  }
                  else{
                  tedu.add(k);
                  }
              }
              if(k.equals("ANIIT"))
              {
                  if(tw.equals("PASS")){
                  }
                  else{
                   tedu.add(k);
                  }
              }
             if(k.equals("PGPJAVA"))
              {
                  if(g.equals("PASS") && tw.equals("PASS")){
                  }
                  else{
                   tedu.add(k);
                  }
              }
              
             //*****End
           }
        
      return tedu;  
    }
    
    
    
}
